// pages/jieguo1.js
var app = getApp();
var that; 
var index;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    items:[
      {
        id :'',
        card: "", 
        score: '',
        st: ''
      },
      {
        id: '',
        card: "",
        score: '',
        st: ''
      },
      {
        id: '',
        card: "",
        score: '',
        st: ''
      },
      {
        id: '',
        card: "",
        score: '',
        st: ''
      },
      {
        id: '',
        card: "",
        score: '',
        st: ''
      },
      {
        id: '',
        card: "",
        score: '',
        st: ''
      },
      {
        id: '',
        card: "",
        score: '',
        st: ''
      },
      {
        id: '',
        card: "",
        score: '',
        st: ''
      },
      {
        id: '',
        card: "",
        score: '',
        st: ''
      },
      {
        id: '',
        card: "",
        score: '',
        st: ''
      },
      {
        id: '',
        card: "",
        score: '',
        st: ''
      }
    ],
    n:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
   // wx.showLoading({
   //   title: '加载中',
   // })
   // setTimeout(function () {
      that.setData({
        n: app.globalData.limit,
      })
    for (var i = 0; i < this.data.n; i++) {
      //this.setData({
      this.data.items[i].id = app.globalData.res.data[i].id,
      //  console.log(app.globalData.res.data[i].id);
     //  console.log(this.data.id[i]);
        this.data.items[i].card = app.globalData.res.data[i].card,
        this.data.items[i].score =app.globalData.res.data[i].score,
        this.data.items[i].st = app.globalData.res.data[i].timestamp
    }
   // console.log(this.data.items[0].id);
   //   wx.hideLoading()
   //  }, 2000)
  },
  
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})